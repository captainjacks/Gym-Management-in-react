const express=require("express");
const app=express();
const bodyParser=require("body-parser");
const port =process.env.PORT ||8082;
require("./db/conn");
const Diet=require("./models/homeschema2");
app.use(express.json());
app.use(express.urlencoded({extended:false}));

app.get("/",(req,res)=>{
    res.send("hello world");
})

app.post("/Diet",async(req,res)=>{
try {
const donUser1=new Diet({
    First_name:req.body.First_name,
    Last_name:req.body.Last_name,
    mail:req.body.mail,
    subject:req.body.subject,
    message:req.body.message,
    
})

    const dor=await donUser1.save();
    res.status(201).send("DIet form submitted sucessfully");
    
} catch (error) {
    res.status(404).send(error);
}


})
app.listen(port,()=>{
    console.log(`running at port ${port}`);
})
