const express=require("express");
const app=express();
const bodyParser=require("body-parser");
const port =process.env.PORT ||8081;
require("./db/conn");
const Query=require("./models/homeschema1");
app.use(express.json());
app.use(express.urlencoded({extended:false}));

app.get("/",(req,res)=>{
    res.send("hello world");
})

app.post("/quern",async(req,res)=>{
try {
const queryUser1=new Query({
    name:req.body.name,
    mail:req.body.mail,
    message:req.body.message,
})

    const Quer=await queryUser1.save();
    res.status(201).send("Query submitted sucessfully");
    
} catch (error) {
    res.status(404).send(error);
}


})
app.listen(port,()=>{
    console.log(`running at port ${port}`);
})
