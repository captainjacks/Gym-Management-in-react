import React from "react";
import bgImage from './video/background-img.mp4'
import './video.css'
import { Link } from "react-router-dom";


function Video()
{
    return(
        <>
        <div className="App">
        <video className="demovideo" id="sik1" autoPlay loop muted>

        <source src={bgImage} type="video/mp4" />

        </video>
        


        <div className="text-wrapper">
            <br /><br /><br /><br />   <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
        <p className="p">Click here for Login/Sign-up </p>
        <button type="button" class="btn btn-primary btn-lg"><Link to="/Login">Login/Sign-up</Link></button>
        </div>
        </div>
        </>
    )
}

export default Video;