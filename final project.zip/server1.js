const express=require("express");
const app=express();
const bodyParser=require("body-parser");
const port =process.env.PORT ||8080 ;
require("./db/conn");
const Register=require("./models/homeschema");
app.use(express.json());
app.use(express.urlencoded({extended:false}));

app.get("/",(req,res)=>{
    res.send("hello world");
})

app.post("/register",async(req,res)=>{
try {
const registerUser1=new Register({
    first_name:req.body.first_name,
    last_name:req.body.last_name,
    mail:req.body.mail,
    password:req.body.password,
    date:req.body.date,
    gender:req.body.gender
})

    const registered=await registerUser1.save();
    res.status(201).send("sign up sucessfull");
    
} catch (error) {
    res.status(404).send(error);
}


})
app.listen(port,()=>{
    console.log(`running at port ${port}`);
})
