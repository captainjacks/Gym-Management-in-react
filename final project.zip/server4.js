const express=require("express");
const app=express();
const bodyParser=require("body-parser");
const port =process.env.PORT ||8083;
require("./db/conn");
const Appa=require("./models/homeschema3");
app.use(express.json());
app.use(express.urlencoded({extended:false}));

app.get("/",(req,res)=>{
    res.send("hello world");
})

app.post("/Appointment",async(req,res)=>{
try {
const killUser1=new Appa({
    first_name:req.body.first_name,
    last_name:req.body.last_name,
    mail:req.body.mail,
    expert:req.body.expert,
    experience:req.body.experience,
    
})

    const dom=await killUser1.save();
    res.status(201).send("Appointment Form submitted sucessfully");
    
} catch (error) {
    res.status(404).send(error);
}


})
app.listen(port,()=>{
    console.log(`running at port ${port}`);
})
