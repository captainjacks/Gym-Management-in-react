const express=require("express");
const app=express();
const bodyParser=require("body-parser");
const port =process.env.PORT ||8084;
require("./db/conn");
const Form=require("./models/homeschema4");
app.use(express.json());
app.use(express.urlencoded({extended:false}));

app.get("/",(req,res)=>{
    res.send("hello world");
})

app.post("/Registra",async(req,res)=>{
try {
const kilUser1=new Form({
    first_name:req.body.first_name,
    last_name:req.body.last_name,
    mail:req.body.mail,
    number:req.body.number,
    address1:req.body.address1,
    address2:req.body.address2,
    city:req.body.city,
    state:req.body.state,
    zip:req.body.zip,
    course:req.body.course,
    payment:req.body.payment,
    
})

    const dok=await kilUser1.save();
    res.status(201).send("Registration submitted sucessfully");
    
} catch (error) {
    res.status(404).send(error);
}


})
app.listen(port,()=>{
    console.log(`running at port ${port}`);
})
